# Neo4j ingestion skill for Claude Code

Install the **entire directory** `neo4j-ingestion/`, not only SKILL.md. This is a Claude Code skill, not an MCP server. It contains offline research, focused technical guidance, direct WebFetch URLs, diagnostic examples and a local CSV analyzer.

## Installation

Unzip the package in a temporary local folder. Then from a macOS/Linux/Git Bash terminal in that folder:

```bash
# User-level (available in your projects)
mkdir -p ~/.claude/skills
cp -R neo4j-ingestion ~/.claude/skills/
```

Alternatively, from the root of the desired repository, with the extracted skill directory at `./neo4j-ingestion`:

```bash
mkdir -p .claude/skills
cp -R neo4j-ingestion .claude/skills/
```

Windows PowerShell (from the extracted folder):

```powershell
New-Item -ItemType Directory -Force "$HOME\.claude\skills" | Out-Null
Copy-Item -Recurse .\neo4j-ingestion "$HOME\.claude\skills\"
```

If that destination already exists, review/replace it intentionally rather than mixing versions. Verify that `.claude/skills/neo4j-ingestion/SKILL.md` is exactly one level beneath `skills/`. Start a new Claude Code session if needed. Invoke `/neo4j-ingestion` or ask Claude to optimize Neo4j relationship ingestion. Official guide: https://code.claude.com/docs/en/skills . Follow corporate restrictions for copying third-party content or installing local skills.

Suggested first prompt:

> /neo4j-ingestion Inspect our current Neo4j ingestion code, version, storage format, actual Cypher, transaction boundaries, and relationship deadlock logs. Use the bundled reference files and WebFetch catalog; do not use WebSearch or transmit internal data. Determine how skewed our graph's incoming relationship distribution is and propose a controlled test matrix for DISJOINT BY, batch sizes, parallel writer counts, grouping, and dense-node CREATE lanes. Do not modify or run production writes. Show how to measure correctness and committed throughput, and explain the next experiment for each profiling symptom.

The local analyzer is optional: `python scripts/analyze_input.py sample.csv --source sourceId --target targetId --limit 100000` from the installed skill directory. Use distinct namespaces only for physically disjoint node populations; same-population edges must share a namespace. It reports aggregate prefix-sample overlap, not real database behavior, and never sends data to a network. Use a representative approved sample. For billion-row workloads compute distributions in your existing ETL system.

Research date: 2026-11-26. All Cypher examples are templates, not executed against a live Neo4j server. Tuning settings and architecture proposals are hypotheses. The original research report is included intact; the newer playbooks add detailed version, compatibility, operational and correctness guidance. Review the public sources for your actual version. No access to the target environment, no measured target throughput, and no claim of guaranteed deadlock-free ingestion.
