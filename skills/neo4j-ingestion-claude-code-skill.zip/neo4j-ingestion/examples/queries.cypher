// REFERENCE ONLY. Run one adapted statement at a time on a test database.
// Do not run this entire file. Schema changes and write PROFILE require approval.
// Assumes :Entity(id) unique; stable relationship ID, endpoints pre-created.
// Native examples require Neo4j 2026.06+ / Cypher 25.
// Use auto-commit, never an enclosing managed write transaction.

// Optional schema on scratch DB, after validating existing records:
CREATE CONSTRAINT entity_id IF NOT EXISTS FOR (n:Entity) REQUIRE n.id IS UNIQUE;
CREATE CONSTRAINT connected_id IF NOT EXISTS FOR ()-[r:CONNECTED_TO]-() REQUIRE r.id IS UNIQUE;

// 1. Independent node upsert phase (wait for complete success before edges).
CYPHER 25
UNWIND $nodes AS row
CALL (row) {
  MERGE (n:Entity {id: row.id})
  SET n.name = row.name
} IN 4 CONCURRENT TRANSACTIONS OF 1000 ROWS
  DISJOINT BY (row.id) ON ERROR RETRY FOR 10 SECONDS THEN FAIL;

// 2. Explicit conservative relationship upsert; EXPLAIN before executing.
CYPHER 25 EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 16 CONCURRENT TRANSACTIONS OF 500 ROWS
  DISJOINT BY (row.sourceId, row.targetId, row.relationshipId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
// IDs above assume disjoint key namespaces for nodes and relationships or tolerate false conflicts.
// Remove EXPLAIN only on approved execution. Use canonical typed keys for mixed populations.

// 3. AUTO candidate: inspect inferred keys in plan. No inferred keys = unrestricted.
CYPHER 25 EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 8 CONCURRENT TRANSACTIONS OF 250 ROWS
  DISJOINT BY AUTO ON ERROR RETRY FOR 10 SECONDS THEN FAIL;

// 4. Dense-target experimental CREATE path. Only proven new edges, stable dense
// target of this type, compatible writers and durable duplicate/replay handling.
// Source ownership only is a deliberate relaxation, not deadlock-free guarantee.
CYPHER 25 EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  CREATE (a)-[:CONNECTED_TO {id: row.relationshipId, value: row.value}]->(b)
} IN 4 CONCURRENT TRANSACTIONS OF 250 ROWS
  DISJOINT BY (row.sourceId, row.relationshipId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
// Compare DISJOINT BY NONE only in controlled testing; qualify external writers.

// 5. Existing relationship updates by indexed identity. Verify exact endpoints if required.
CYPHER 25 EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH ()-[r:CONNECTED_TO {id: row.relationshipId}]->()
  SET r.value = row.value
} IN 8 CONCURRENT TRANSACTIONS OF 500 ROWS
  DISJOINT BY (row.relationshipId) ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
// Add ordering/version guards if stale events are possible; missing MATCH must be reconciled.

// 6. Reconciliation-oriented status reporting. Test with duplicates and missing endpoints.
// A unit subquery can commit despite unmatched endpoints; returning aggregate makes no-match visible.
CYPHER 25 EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
  RETURN count(r) AS matchedEdges
} IN 8 CONCURRENT TRANSACTIONS OF 250 ROWS
  DISJOINT BY (row.sourceId, row.targetId, row.relationshipId)
  ON ERROR RETRY FOR 10 SECONDS THEN CONTINUE REPORT STATUS AS status
RETURN row.relationshipId AS id, matchedEdges, status;
// Persist all unresolved IDs; check status.committed and matchedEdges exactly one.
// Output ordering is not guaranteed. For large chunks consume results efficiently.

// 7. 5.23+ legacy native concurrent example (no DISJOINT BY).
// External coordination, or controlled experiment; retry clause availability depends on release.
EXPLAIN
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 4 CONCURRENT TRANSACTIONS OF 250 ROWS;
// 5.21/5.22: use CALL { WITH row ... } form, check minor release features.

// For version 2026.10+ replace EXPLAIN with PROFILE only on scratch fixture.
// PROFILE executes writes. Never use it on production merely for diagnostics.
