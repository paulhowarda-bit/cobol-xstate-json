# Large-scale ingestion architecture and correctness

Use with the research report and native Cypher playbook. The approaches below are engineering recommendations, not performance guarantees.

## Choose an ingestion mode before tuning

| Situation | First candidate | Important constraint |
|---|---|---|
| Initial build of hundreds of millions/billions of edges | `neo4j-admin database import full` | New/rebuilt database, maintenance and operational plan; not ordinary online transactions |
| Large staged additions or supported updates | `neo4j-admin database import incremental` | Enterprise/version-dependent features, required schema and offline stages; verify exact release and backup/restore requirements |
| Live stream, continuously available graph | Driver or connector batching, native concurrent subqueries | Correct replay, latency, read SLA and global writer budget |
| Large files into live graph | LOAD CSV or bounded driver chunks; transactional subqueries | Input throughput, memory, scheduling and checkpointing |
| Data lake/ETL | Spark connector with upstream grouping | Connector write semantics, partitions and total writer count |

Administrative import is a separate implementation from Cypher transactional ingestion. Do not tune it with DISJOINT BY. Verify file headers, IDs, duplicate/missing endpoint handling, schema, disk space, supported import options, recovery and downtime. Use a scratch import and compare business counts; do not overwrite a database as a tuning experiment. Sources: Operations Manual import links in sources.md.

## Optimize schema and write semantics

1. Choose immutable, canonical node IDs scoped to logical entity type and tenant. Use matching unique constraints/indexes for endpoint lookups. Ensure indexes are ONLINE before measuring. `EXPLAIN` should demonstrate selective index lookup rather than large label scans or Cartesian expansion.
2. Split independent node creation and node updates from relationship work. Commit endpoint creation before dependent relationships. Do expensive transforms, validation, deduplication and type conversion upstream. Avoid repeated MERGE of the same reference node for every edge.
3. Relationship `MERGE` with missing pattern can take exclusive endpoint locks even when endpoints are dense; check `LockingMerge`, `MergeInto` and actual query plan. `CREATE` can avoid the existence check but does not preserve MERGE semantics. Prefer `CREATE` only for proven new edges with durable replay safeguards; do not silently change business behavior. For true upserts, use bound indexed endpoints and deterministic identity. For existing relationship property-only changes use indexed relationship lookup where supported, avoiding endpoint re-expansion. Include additional unique keys if properties change.
4. Relationship property uniqueness constraints available since 5.7. A unique property is not an existence guarantee unless enforced separately; verify all rows supply a non-null stable ID. Use a key constraint if supported and justified. A duplicate violation may abort the entire batch; reconcile already committed records and resubmit only unresolved records. Never ignore arbitrary constraint errors as duplicate success; compare expected endpoints and payload.
5. Separate deletion/label changes, counters and high-contention property updates from edge insertions. Operations can still interfere across lanes. Ensure application-level scheduling coordinates them or maintain normal database retry protection. Do not update a hot node's summary count on every inserted edge unless semantics require it; consider separately reconciled aggregate paths if permitted.

## Streaming / driver boundaries

- Plain driver microbatches (`UNWIND $rows` with one explicit transaction per batch) provide external transaction ownership and clear acknowledgement units. Native `CALL ... IN CONCURRENT TRANSACTIONS` provides inner batching in a single implicit outer query. Do not nest it in managed explicit write transactions. Choose one primary concurrency owner; multiple layers multiply contention.
- Design stable event IDs, relationship identities and versions. Use canonical tuple encoding, not ambiguous concatenation. Detect stale or duplicate events; preserve required per-identity order. A `MERGE` followed by unconditional SET is not necessarily replay-safe if old events can overwrite new state.
- Commit/ack protocol: take a bounded chunk -> validate -> write -> consume result -> reconcile IDs and payload/version -> persist durable success/failure state -> advance only contiguous acknowledged offsets. A crash after commit before acknowledgement is possible. External dedup caches alone cannot establish exactly-once. If transactional progress marker in Neo4j is appropriate, commit it atomically with the relevant mutation; do not create a single global hot marker. Validate unknown-commit recovery and rebalancing.
- With native inner commits, the outer query can fail after some data is committed. Do not replay a raw CREATE chunk blindly. Use idempotency, ledger or database reconciliation. Missing MATCH can silently skip a row even when the batch succeeds. Verify complete business identity accounting, not just query success.
- Bound queue by bytes/rows and latency; apply backpressure before database saturation. Avoid unbounded retries or holding ownership during long retry sleeps unless needed for semantics. Differentiate transient errors from invalid input and authorization failures. Keep dead-letter/reconciliation processes durable and observable.

## Kafka, Spark, APOC

- Kafka: partition ordering is local to a Kafka partition, not all endpoints of a graph relationship. Keying by source does not isolate target conflicts. Inspect connector strategy (Cypher, Pattern, CDC, CUD), version, task count, batching, offset/replay behavior and error handling. Some connector strategies/versions provide exactly-once features using database offsets; do not generalize to arbitrary Cypher strategies. Connectors may wrap statements in a transaction: do not embed CALL IN TRANSACTIONS without documented support. Where native subqueries are needed, use a suitable implicit driver job. See connector docs.
- Spark: push transformations into Spark, prepare indexed endpoint keys, avoid driver `collect()` of huge datasets, measure actual partitions and Neo4j transactions. Standard connector guidance may recommend serial relationship writes as a safe default; the Parallel Spark Loader provides explicit graph-aware grouping. Verify library compatibility and output ordering, partition boundaries and exact keys. Never combine independent Spark partitions with high server-side concurrency blindly. Include ETL cost in end-to-end timing.
- APOC: `apoc.periodic.iterate` remains relevant for older installations but is deprecated in Cypher 25 from Neo4j 2026.04. Inspect its `batchSize`, `parallel`, retry, execution pool and failure counters. When migrating, translate batch input semantics carefully and validate replay and partial-failure behavior. Native Cypher is the forward path; DISJOINT BY is not a drop-in option for APOC.

## Degree-aware scheduling

Degree is historical topology, not write temperature. In block format density is relationship-type-specific and depends on data size; a hard-coded degree threshold is insufficient. For record formats, the conventional threshold is 50 total relationships, subject to configuration. Neo4j's dense-node engine can allow compatible edge changes without holding exclusive node locks throughout the transaction; commit, constraint and other locks remain. Confirm store format separately from server version. Existing upgraded stores can retain their old format.

### Conservative schedule

For genuinely disjoint source and target populations, hash or weight each into N partitions. Pair `(i, (i+phase) mod N)` for phases 0..N-1; at most one writer owns a partition in that phase. Never apply this directly to same-population relationships. For a general graph, use one namespace, group by unordered pair of partitions (preserve actual edge direction), and edge-color the complete partition graph or use a round-robin matching. Even N: N-1 cross-partition phases, up to N/2 disjoint writers; within-partition work in a separate phase. A phase barrier waits for all participating transactions to finish. Weight by actual write cost, not number of distinct nodes. Legacy record chains can introduce indirect conflicts even with disjoint endpoint keys; retain retries and validate.

### Work-conserving dispatcher (proposal)

For continuous data, avoid global phase barriers when skew makes workers finish at different times. Group into bounded microbatches. For each batch, compute exclusive resources and optionally qualified shared resources. Atomically reserve the entire set or reserve none, using one authoritative coordinator. Schedule oldest eligible batch with aging/fairness, bounded queue and global worker budget. Release after known transaction completion, not merely after sending the query. Uncertain outcome triggers reconciliation. Failover must fence old ownership and handle in-flight transactions; a simple TTL lease does not prevent an expired owner from continuing a write. Do not promise zero deadlocks across uncoordinated external sessions or engine resources. Monitor dispatcher itself for throughput and starvation.

Suggested operation policies: sparse CREATE => exclusive endpoint; dense CREATE => bounded shared permit at qualified dense endpoint and exclusive sparse endpoint; existing relationship UPDATE => relationship identity plus relevant indexes/other resources; missing MERGE => conservative endpoints; node mutation or density transition => conservative exclusivity. These are admission-control policies, not actual Neo4j lock modes. Validate using stress tests and actual exception data. If a mixed batch contains an exclusive operation for a key, use exclusive for the entire batch. Do not allow independent lanes to bypass ownership.

### Adaptive budget (proposal)

Start with shared budget 1 for each tested dense hot resource. Increase by 1 only when backlog exists, successful rate grows, and p99/lock waits/failure rate remain within limits for several windows. Reduce (e.g. halve) when congestion crosses thresholds. Add cooldown, hysteresis, fairness, global cap and minimum observation volume. Track per-resource latency, retries and backlog, plus database-level metrics; do not infer safe budget from degree alone. Validate safe CREATE path before enabling shared permits; a node may be structurally dense yet subject to exclusive MERGE. Cold resources can be managed with coarse partitions if memory is a concern; use exact keys for hottest resources.

### Physical modeling changes (last resort)

Bucket a logical hub into stable attachment nodes by counterpart hash, time or business domain, link them to the logical hub once, then ingest edges into the buckets. This changes traversals, queries, constraints and graph algorithms. Benchmark query overhead and preserve logical projection for analytics. Plan resharding and stable relationship identity. Do not physically split a node merely to avoid a deadlock before investigating storage format, CREATE/UPDATE semantics and scheduling. Get domain owner approval.
