# Benchmarking, diagnosis and rollout protocol

## Inventory checklist

Record exact version/edition, Cypher dialect, actual format, cluster writer topology, cores, heap/page cache, disk latency, indexes/constraints, current driver/connector versions and producer topology. Collect sanitized actual deadlock exceptions including resource and transaction IDs. Identify writes on each endpoint and whether other writers mutate labels, properties, relationships or constraints. Capture throughput target, peak burst, acceptable p99, read SLA, durability and recovery requirements. No production access is presumed.

Read-only starting commands (check permissions and version):

```cypher
CALL dbms.components();
SHOW DATABASES YIELD *;
SHOW INDEXES YIELD *;
SHOW CONSTRAINTS YIELD *;
SHOW TRANSACTIONS YIELD *;
SHOW TRANSACTIONS YIELD transactionId, currentQueryId, status, waitTime, elapsedTime, activeLockCount, estimatedUsedHeapMemory RETURN * ORDER BY waitTime DESC;
```

Inspect `CALL dbms.listActiveLocks($queryId)` using actual current query ID and suitable privilege. Admin `neo4j-admin database info <database>` may reveal physical format; use appropriate installed command/permissions. Do not assume SHOW DATABASES always reports it. Redact private query text and parameters. Deadlock resource types can include NODE, RELATIONSHIP, RELATIONSHIP_GROUP, DEGREES, INDEX_ENTRY; exact meanings vary by version. Use exception evidence, not a single lock snapshot, to distinguish hot waits from cycles. Capture logs with approved observability settings, not uncontrolled production tracing.

## Skew analysis

Use upstream arrival data to compute endpoint frequency by canonical physical ID (both roles), type, op and time window; measure top 1/10/100 key concentration, percentiles, pair and multi-key correlation, distinct keys per batch and hotspot burst duration. Degree distribution: use existing production telemetry or a bounded snapshot query. Full scan of nodes and relationship degrees can be expensive; do not run unbounded diagnostics on a live large graph. For example, on a test sample:

```cypher
MATCH (n:Entity) WHERE n.id IN $sampleIds
WITH n, COUNT { (n)-[:CONNECTED_TO]-() } AS degree
RETURN count(*) AS sampled, avg(degree) AS mean,
       percentileDisc(degree,0.50) AS p50,
       percentileDisc(degree,0.99) AS p99,
       max(degree) AS maxDegree;
```

Avoid claiming a sampled maximum is the global maximum. For truly massive data use upstream approximate heavy-hitter/sketch algorithms, distributed grouping, or precomputed histograms. The included Python analyzer reads a bounded prefix and uses exact counters only within that prefix; it does not estimate production performance or dense status.

## Controlled experimental design

Create repeatable snapshots at the same starting degree and indexes. Test representative production input slices and synthetic variations: hot key fraction 1/10/25/50/90%; degree around sparse-to-dense transitions plus 1000/100000/1000000; both same-population and bipartite; CREATE/MERGE/UPDATE/DELETE mixes; uniform and real skew; active reads and concurrent producers. Do not mistake a second MERGE run on already existing edges for new-edge throughput. Capture warm/cold cache policy, test length, warmup, steady-state and recovery. Repeat winners three or more times, record median and variability. Include data preprocessing and transport time in end-to-end comparison.

Staged matrix (avoid a huge Cartesian product):

| Stage | Change | Hold fixed |
|---|---|---|
| 0 | current prod baseline, serial baseline | fixture, semantics, resources |
| 1 | original vs grouped, both-endpoint explicit keys | 4 or 8 writers, 250/500 rows |
| 2 | rows 50,100,250,500,1000,2000, optional 5000 | writer count, keys, grouping |
| 3 | 2,4,8,16,32, optional 64 workers | best 2 row sizes, other factors |
| 4 | explicit vs AUTO vs NONE (controlled), external grouping | top settings and semantics |
| 5 | qualified dense CREATE lane, sparse lanes, mixed ops | replay semantics, equivalent fixture |
| 6 | multiple outer queries, real concurrent read load | global budget, winning settings |
| 7 | failure injection, restart, unknown commit, failover | same correctness requirements |

Use a scratch environment for PROFILE because it executes writes. Use unprofiled runs for final timing. On 2026.10+, collect concurrent-transactions map from profiled driver plan (see native-cypher.md). For earlier releases, use actual driver batch latency and transaction sampling. Distinguish queued from running, lock wait from commit time, and retries from unique operations.

## Metrics and selection

Primary objective: verified distinct committed business edges / end-to-end elapsed seconds. For updates/deletes use correctly applied business operations; for mixed workload separate counters per operation. Also measure offered rate, backlog age, missing/duplicate/stale identities, actual mutations/row, distinct keys per batch, actual rows per commit, total committed/rolled back attempts, retries, deadlocks, p50/p95/p99 transaction & read latency, CPU, heap, GC, disk/log throughput & latency, page-cache misses, cluster replication health and checkpoint cost. Compare normalized deadlocks/retries per 1000 attempts AND per committed unit. Record no-match rows and failed IDs. Do not compare rates from incompatible semantics.

Select the smallest configuration within e.g. 5% of best sustained eligible throughput, only if meets pre-agreed SLA and headroom (proposed heuristic, not product rule). If average concurrency is low with a ready queue, reducing conflict footprint is preferable to raising the ceiling. If high with low throughput and high resource utilization, scaling writers is counterproductive. If no input, fix supply. If retry rate rises, investigate locks rather than lengthen timeout. Set stop conditions and backpressure before runs.

## Results template

```csv
run_id,version,edition,store,operation,fixture,hot_fraction,row_order,key_policy,outer_queries,workers,batch_rows,offered_rows,verified_committed_unique,elapsed_s,edges_per_s,failed_rows,missing_rows,duplicate_rows,deadlocks,retries,avg_concurrency,avg_queued_batches,p99_tx_ms,p99_read_ms,peak_heap_mb,cpu_pct,log_p99_ms,replication_lag_ms,backlog_age_ms,notes
```

Record raw artifact paths, commands, settings, timestamps, test data generation seed and snapshot ID. Ensure sensitive artifacts remain local. Include preprocessing time; avoid invented values for unavailable metrics. For each change record expected hypothesis, result, decision and reason.

## Canary and recovery

Agree thresholds with owners before rollout: sustained/burst rates, maximum backlog age, p99 read/write budgets, zero missing/duplicate business identities, ordering/version correctness, memory/log/replication headroom, retry/failure thresholds. Start on representative controlled subset, then gradually ramp; maintain a kill switch and ability to drain in-flight work. Roll back to prior writer/batch/key settings with proper coordination; rollback configuration does not undo committed data. Keep prior graph semantics unless an approved migration has its own reversible plan. If uncertain commits or failures occur, pause offset advancement, reconcile and resume idempotently. Test recovery during planned non-production failures before deployment.
