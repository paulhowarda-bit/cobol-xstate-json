# Native Cypher concurrency and DISJOINT BY — operating playbook

Research checked 2026-11-26. Primary authority: https://neo4j.com/docs/cypher-manual/current/subqueries/subqueries-in-transactions/ . Read the installed release's manual when different. See sources.md.

## Compatibility and transaction semantics

- Sequential `CALL { ... } IN TRANSACTIONS` is available in older releases; concurrent form is available from Neo4j 5.21. Check the exact minor version; variable scope `CALL (row)` arrived in 5.23 (earlier versions use importing `WITH`). Do not use newer syntax blindly on 5.x.
- `DISJOINT BY` requires Neo4j 2026.06+ and Cypher 25; not valid on sequential `IN TRANSACTIONS` or Cypher 5. `PROFILE` concurrency stats require 2026.10+. `MergeInto` operator introduced 2025.11. APOC periodic iterate is deprecated in Cypher 25 from 2026.04.
- Run the outer statement in an implicit transaction (e.g. Java `session.run(query, params).consume()`), not inside `executeWrite` / explicit transaction. Browser requires `:auto`. Fully consume the result. Driver retry behavior differs by version; do not assume outer replay is safe.
- Form inner batches from rows produced *outside* the CALL. `UNWIND` a list inside CALL would not batch its elements individually. Input rows are not necessarily edges: fanout, filters and unmatched endpoints change mutations per row. Batch scheduling may run partially filled batches.
- Default row size is 1000. The specified concurrency is a ceiling, not guaranteed utilization. Parameterization is supported for numeric concurrency, row size and retry duration in the current manual; verify exact release. Specify explicit values for reproducible tuning. Avoid a giant `$rows` list; stream or use bounded outer chunks. Limit output rows to avoid result-side backpressure, unless per-row status is needed.
- Concurrent batches can commit in any order; no assumption of visibility of earlier input rows. Separate dependent phases with a durable completion barrier. Outer query failure leaves earlier committed inner transactions intact, and in-flight batches may still commit.

## Baseline query (true upsert)

```cypher
CYPHER 25
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 16 CONCURRENT TRANSACTIONS OF 500 ROWS
  DISJOINT BY (row.sourceId, row.targetId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL
```

Assumptions: canonical same-population node IDs, unique endpoint index, stable relationship ID, pre-created endpoints, no independent conflict resource omitted. Use additional relationship key if necessary. Missing matches can silently do no work; validate separately. For actual ingestion use deterministic business data and explicit reconciliation. This example has not been executed in a Neo4j test instance.

The equivalent configurable candidate is `IN $workers CONCURRENT TRANSACTIONS OF $batchRows ROWS ... ON ERROR RETRY FOR $retrySeconds SECONDS THEN FAIL`; use `EXPLAIN` to validate against the target release. For older versions remove DISJOINT BY and coordinate conflicting batches externally. Do not use managed write transactions around this query.

## How DISJOINT BY works

It supplies row-level resource identities to the runtime before the subquery executes. The scheduler forms batches and prevents simultaneously running batches sharing declared resource values. It is not a database lock itself, does not guarantee input commit order, and is not global coordination across queries. Other producers can still conflict. Engine-specific indirect locks, missing keys and constraints can still deadlock. The official same-population account example declares both source and target IDs; test cross-role overlap on the deployed release.

- Explicit `DISJOINT BY (row.sourceKey, row.targetKey, row.relationshipKey)` is a complete declaration, not added to AUTO. Use only values in outer scope. Stable non-null scalar keys should represent incompatible resources. Use globally consistent typed identity namespaces; avoid role prefixes when the same node appears in either role. Canonicalize aliases upstream. For disjoint labels, namespace raw IDs by actual entity type. Avoid constant keys, broad label/type-only keys and pair-only keys when a single shared endpoint conflicts. Do not assume arrays are exploded into individual keys.
- `DISJOINT BY AUTO` asks planner to infer resources, notably indexed MERGE patterns. Check `EXPLAIN` TransactionForeach/TransactionApply Details for actual expressions. No inferred expressions means unrestricted execution. AUTO is not proof that all real conflicts are covered.
- `DISJOINT BY NONE` explicitly disables scheduling. Use for independent workloads or controlled tests exploiting verified dense CREATE concurrency; keep database locks and retries. Do not turn off scheduling for a hot MERGE path simply to increase utilization.
- Global setting `dbms.cypher.transactions.default_subquery_batch_strategy` accepts NONE, AUTO, DEFAULT (currently NONE); query clause takes precedence. Use query-local overrides first; verify actual settings via `SHOW SETTINGS YIELD name, value WHERE name STARTS WITH 'dbms.cypher.transactions.' RETURN name,value` with suitable privileges. Never alter shared defaults without review.

### Conflict-key design examples

| Scenario | Candidate | Qualification |
|---|---|---|
| Same-label graph | `(row.sourceKey,row.targetKey)` | identical namespace in both directions |
| Both endpoints + unique relationship resource | `(row.sourceKey,row.targetKey,row.edgeKey)` | edge identity distinct namespace; include all independently conflicting keys |
| Indexed relationship-only property update | `(row.edgeKey)` | no topology change; include other unique property conflicts |
| Sparse source + stable dense target, CREATE-only | `(row.sourceKey)` | experimental, not generally safe; qualify dense target and all other writers |
| Independent pre-partitioned work | `NONE` | external ownership spans complete transaction and all competing lanes |
| Merges of indexed identities | `AUTO` | inspect plan; test against explicit keys |

Test fixtures: A→B vs C→A; A→B vs B→A; duplicate edge ID; self-loop; same ID in different labels; alias referring to same node; source/target collisions; unrelated work; external session updating hot endpoint. Verify no missed data and inspect lock failures, not just elapsed time. For complicated dynamic write sets, use external admission control rather than guessing scalar expressions.

## Batch composition: the lever most commonly missed

For a randomly mixed stream with a hot key in fraction p of rows, a fixed-size B batch touches that key with probability `1-(1-p)^B` assuming independent sampling. With p=1% and B=500 this is about 99.3%; almost every batch becomes mutually incompatible under exclusive scheduling. This is a model, not a description of the native scheduler, which may form partial batches.

1. Sample canonical endpoint frequencies in the arrival stream, combining roles. Count per relationship type and operation; capture bursts, not merely daily averages.
2. Compare shuffled/original input with grouped by hottest relevant endpoint, then other endpoint; also test weighted pair grouping. Use upstream external sort/partition or bounded in-database sorting, not a global sort of billions of rows in one transaction.
3. Interleave **independent groups**, not random edges. An unbroken sequence for a single exclusive hot key can starve other ready work. For same-population graphs use matching/graph coloring or a dynamic scheduler rather than assuming source/target partitions are independent.
4. Record distinct conflict keys per batch, number of hot keys per batch, and actual rows per commit. If an input row expands to 100 writes, reduce row count or pre-flatten safely. Bound bytes, mutation count, distinct keys and time as well as input rows.

## Iterative tuning procedure

Keep a common dataset and reset the graph to the same state for every test. Use identical schema, hardware, cache policy, concurrent reads and producer count. For a very large deployment use a representative subset then sustained realistic load; do not extrapolate linearly. See benchmark.md.

1. Serial baseline: `IN TRANSACTIONS OF 500 ROWS` (no DISJOINT BY). Record actual committed rate and resource usage. Record production baseline too.
2. Compare 4 and 8 concurrent writers with explicit conservative keys, initially 100/250/500 rows. Compare input ordering before escalating. For severe skew start at 50 or 100; for low-conflict cheap CREATE test 1000/2000 and optionally 5000. These are test values, not documented optimums.
3. Fix workers at 4 or 8; sweep batch rows 50,100,250,500,1000,2000, optionally 5000. Select top eligible candidates by throughput and tail latency. Decrease rows when lock lifetime, memory, retries or footprint grow; increase when commit overhead dominates and resources allow. Smaller rows can improve scheduler parallelism but increase transactions/sec and log overhead.
4. For best two batch sizes, sweep workers 2,4,8,16,32, optionally 64 after capacity review. Stop when throughput flattens, p99/lag/heap exceeds limits, or failures rise. Prefer smallest configuration near best eligible throughput (e.g. within 5%, proposed). Tune global producer budget: four queries at 16 may attempt 64 inner batches plus outer work; no global coordination from DISJOINT BY.
5. Test explicit vs AUTO (inspect inferred keys) vs NONE (only safe test or validated lane), original vs grouped, and dense vs sparse lanes. Repeat winners with realistic concurrency and reads. Do not compare CREATE vs MERGE as equivalent unless business correctness is maintained.
6. Use profiler/metrics to choose next intervention. Re-run unprofiled for actual timing. Stop a test if it causes operational risk. Capture result artifact and rationale for each change.

## New concurrency profiler (2026.10+)

Use `CYPHER 25 PROFILE ...` with a **test** write query. Inspect TransactionApply/TransactionForeach operator `Concurrency` column (peak and time-weighted average) and driver plan argument `concurrent-transactions`. This includes:

| Field | Interpretation |
|---|---|
| concurrencyLimit | configured maximum |
| peakConcurrency, avgConcurrency | achieved peak and mean running batches |
| peakQueuedBatches, avgQueuedBatches | ready but not started batches |
| peakStartGapNanos, avgStartGapNanos | time between queueing and start |
| batchesQueued, batchesStarted | attempts (including retries); scheduler may use partial batches |
| innerTransactionsStarted, innerTransactionsCommitted | attempts and commits; difference is rollback count |
| retries | retries scheduled, not necessarily all executed |

Batch attempts include repeated work; don't mistake attempts for distinct committed rows. Delay between retry attempts is not queued time. Use end-to-end input identities/counters to measure success. On older versions use transaction sampling and driver instrumentation, not invented PROFILE fields.

| Observed signal | Likely cause | Next experiment |
|---|---|---|
| avgConcurrency near limit, queue high, headroom | writer ceiling | raise workers one step |
| avgConcurrency low, queue ~0 | slow input, outer query or sparse supply | optimize upstream, indexed lookup, producer pacing |
| avgConcurrency low, queue high | scheduler conflicts or slow result consumption | inspect keys, group/partition, smaller batches, consume results; don't blindly raise workers |
| retries high with explicit keys | unmodeled or external conflicts, legacy chain locks | examine exceptions, key aliases, other sessions and store format |
| lock waits high, few deadlocks | hotspot serialization | shorter transactions, separate lane, measure dense path |
| avgConcurrency high, throughput flat, CPU/log/replication saturated | server limit | stop increasing concurrency; address resources or backpressure |
| large transaction state or GC | footprint | lower rows/worker count and bound outer chunks |
| many partial batches | scheduler fragmentation | measure actual batch size and overlap; regroup; compare |

## Retry and failure semantics

`ON ERROR RETRY FOR 10 SECONDS THEN FAIL` retries transient errors with backoff; retry duration is not a lock acquisition or transaction timeout. Current default is 30 s; timer starts with first retry scheduled and even zero allows at least one retry. Explicit fallback options FAIL (default), BREAK, CONTINUE. With concurrent execution, in-flight batches can commit despite failure/break. No automatic rollback of previous inner commits. Retry budget must fit service latency; excessive retry hides contention.

If intentionally allowing continuation, use `ON ERROR RETRY FOR 10 SECONDS THEN CONTINUE REPORT STATUS AS status`, return input ID, status and a result indicator to identify no-match vs committed mutation. Validate status schema in target docs. Durable failed-row tracking and replay are mandatory. A committed batch can contain zero matching endpoints; no-match is not an error by itself. Use separate validation/reconciliation and do not acknowledge missing rows. An outer connection failure creates an unknown commit outcome; inspect durable identity/checkpoint and retry idempotently.
