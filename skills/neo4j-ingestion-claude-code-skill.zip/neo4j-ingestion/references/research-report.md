# High-throughput Neo4j relationship ingestion under skewed node degree

**Technical research and implementation guide**  
**Research date:** November 26, 2026  
**Scope:** Online parallel writes, relationship-heavy graphs, supernodes, deadlock prevention, and transaction tuning.  
**Status:** Research-based recommendations and proposed experiments; not validated against the target production environment.

## 1. Executive summary

Graphs with highly variable node degree require different ingestion strategies from uniformly distributed graphs. A small number of nodes may participate in a disproportionately large share of incoming relationships. Running more concurrent transactions against these nodes can increase locking, retries, and latency while reducing committed throughput.

The most important observation is that **sharing a dense endpoint is not inherently incompatible with concurrent relationship creation**. Neo4j's storage engine can support concurrent modifications of relationships attached to dense nodes. However, relationship `MERGE`, sparse endpoints, node changes, unique constraints, and internal storage structures can still introduce conflicting locks.

Recommended order of investigation:

1. Establish the exact Neo4j version, edition, storage format, Cypher query plan, and deadlock resource types.
2. Separate endpoint creation and node updates from relationship insertion; use indexed endpoint identity lookups.
3. Separate new relationship `CREATE`, existing relationship property updates, and true upserts. Preserve replay and uniqueness semantics.
4. Evaluate Enterprise block storage if the database uses a legacy record format.
5. On Neo4j 2026.06+ with Cypher 25, benchmark `DISJOINT BY` with explicit resource keys; use 2026.10+ concurrency profiling where available.
6. Tune row grouping, transaction size, and concurrency jointly. Do not choose a single batch size based on global average degree.
7. If exclusive scheduling serializes hot dense nodes, test a specialized, bounded-concurrency `CREATE` lane that exploits native dense-node behavior.
8. If required, implement weighted partitioning and conflict-aware scheduling across producers. Physically shard supernodes only if less disruptive measures fail.

Optimize **committed unique relationships per second**, subject to latency, reliability, resource, and application-read service-level objectives. Zero deadlocks with one writer is not necessarily a better result than high throughput with a small, bounded retry rate.

## 2. Why skew matters

Distinguish structural degree (relationships already present) from write temperature (incoming operations per unit time). These quantities can differ substantially. A million-degree reference node may receive no writes, while a new node may receive a sudden burst and be sparse at the start of that burst.

Consider this illustrative distribution, not actual workload measurements:

| Node population | Share of nodes | Share of incoming relationship endpoint references |
|---|---:|---:|
| Cold | 90% | 10% |
| Warm | 9% | 20% |
| Hot | 0.9% | 30% |
| Extreme hotspots | 0.1% | 40% |

Uniform hashing of node IDs balances identities but may not balance write work. Measure incoming frequency by physical node identity, relationship type, operation, and time window. A node can occur in either endpoint role; aggregate both roles when estimating its write temperature.

A deadlock occurs when transactions hold resources that another needs and form a circular waiting dependency. For example, transaction T1 holds a resource for A and needs B, while T2 holds B and needs A. Neo4j aborts a victim transaction. A hotspot also causes ordinary lock waiting without necessarily producing a deadlock. Track both.

A batch that touches many unrelated hot nodes spreads contention across the graph. Its lock footprint is more informative than its row count. Ten rows that perform multiple graph mutations can be more expensive than hundreds of simple edge insertions.

## 3. Storage engine and relationship locking

Neo4j's documented lock behavior distinguishes sparse and dense nodes [1]. The following is a conceptual summary; additional index and internal locks are possible.

| Mutation | Main conflict concern |
|---|---|
| Create relationship with sparse endpoint | Exclusive node access may be required |
| Create relationship with dense endpoint | Shared deletion-prevention and degree synchronization; finer commit locking |
| Delete relationship | Endpoint synchronization plus relationship lock |
| Update existing relationship properties | Relationship lock, plus relevant index maintenance |
| Update node properties or labels | Node lock; label changes can interact with degree synchronization |
| Relationship MERGE when missing | May exclusively lock endpoints to prevent duplicate creation |

For legacy `standard`, `aligned` and `high_limit` stores, the usual density threshold is 50 total relationships, configurable through `db.relationship_grouping_threshold`. Once classified as dense, a record-format node remains dense. In Enterprise `block` stores, density is per relationship type and depends on storage size; approximately 50 relationships of that type is indicative, not a guaranteed cutoff. A node may be dense for one type and sparse for another [1, 2].

Block storage uses a different relationship representation, including node-local storage and dense relationship trees. It became generally available in 5.16 and the default for new Enterprise databases in 5.22 [2]. An upgraded database may retain its existing store format.

Legacy record formats can have indirect contention on existing relationship records, even if the new edges have disjoint endpoint sets. Published endpoint-partitioning algorithms explicitly qualify their guarantees by requiring block storage [8, 9]. Do not assume endpoint disjointness alone proves a database-wide absence of deadlocks.

Check the environment:

```cypher
CALL dbms.components();
SHOW DATABASES YIELD name, store;
SHOW CONSTRAINTS;
SHOW INDEXES;
```

Administrative alternative: `neo4j-admin database info neo4j` (substitute the actual database name; check command and access requirements for the installed version).

If migration is relevant, test it on a restored copy, plan downtime and rollback, and validate data and indexes. Do not modify the density threshold or storage format in production without a measured justification.

## 4. Optimize the write query first

Create indexed endpoint identities before ingesting relationships:

```cypher
CREATE CONSTRAINT entity_id IF NOT EXISTS
FOR (n:Entity) REQUIRE n.id IS UNIQUE;
```

Load nodes in a separate completed phase. The following relationship-only query assumes both endpoints exist and IDs are non-null, canonical, and unique:

```cypher
UNWIND $rows AS row
MATCH (a:Entity {id: row.sourceId})
MATCH (b:Entity {id: row.targetId})
CREATE (a)-[:CONNECTED_TO {
  id: row.relationshipId,
  value: row.value
}]->(b);
```

Avoid combining endpoint `MERGE`, node property/label changes, relationship `MERGE` and other dependent writes into one large transaction when the business process permits separating them.

### CREATE versus MERGE

For a missing relationship, `MERGE` can require exclusive locks on both bound endpoint nodes, even when they are dense [3]. This may negate some dense-node concurrency advantages. Use `EXPLAIN` to inspect the actual plan (`LockingMerge`, `LockNodes`, `MergeInto`, indexed seeks and expansions) rather than inferring all locking behavior from the Cypher text [4]. Use `PROFILE` only on a test dataset because it executes the writes.

For append-only relationships, prefer `CREATE` if the application can prove the relationship is new. To enforce stable business identity at the database level (relationship property uniqueness supported from Neo4j 5.7):

```cypher
CREATE CONSTRAINT connected_to_id IF NOT EXISTS
FOR ()-[r:CONNECTED_TO]-() REQUIRE r.id IS UNIQUE;
```

Generate a deterministic ID from an unambiguous canonical encoding of the relationship type, endpoint identities and immutable business/event key. If multiple edges between the same endpoints are valid, include the distinct business key. Enforce non-null IDs in input validation (a uniqueness constraint alone does not require property existence).

`CREATE` plus a uniqueness constraint prevents duplicate committed identities, but is not a drop-in idempotent upsert: a duplicate can abort a whole inner transaction. Implement durable reconciliation of partially committed batches, distinguish duplicates from genuine identity conflicts, and retry only uncommitted work. Never interpret every constraint violation as success.

For known existing relationships, benchmark a direct indexed update path:

```cypher
UNWIND $rows AS row
MATCH ()-[r:CONNECTED_TO {id: row.relationshipId}]->()
SET r.value = row.value;
```

For true upserts where absence is unknown, use `MERGE` with already bound endpoints and the correct stable identity, and schedule conservatively. Do not substitute `CREATE` unless its semantics are correct. Updates to the same relationship need conflict/order handling; an older event must not overwrite a newer event.

**Missing endpoints:** `MATCH` silently drops unmatched rows. Validate input and reconcile requested versus applied IDs; report/quarantine missing endpoints rather than acknowledging an entire input batch blindly.

## 5. Native concurrent transactions and DISJOINT BY

### 5.1 Starting query

`DISJOINT BY` requires Neo4j 2026.06 or newer and Cypher 25 [5]. It is available on concurrent transactional subqueries, not ordinary sequential `IN TRANSACTIONS`. For example, with existing nodes and true upserts:

```cypher
CYPHER 25
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 16 CONCURRENT TRANSACTIONS OF 500 ROWS
  DISJOINT BY (row.sourceId, row.targetId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
```

This is a starting configuration, not an optimum. Submit it as an implicit/auto-commit query (for example, `session.run()` in a driver, or `:auto` in Neo4j Browser); consume the result and check errors. Do not wrap it in an explicit or managed outer write transaction. Inner commits are independent; failure of the outer query does not roll back already committed batches. Concurrent batches do not promise input commit order.

| Clause | Interpretation |
|---|---|
| `16 CONCURRENT TRANSACTIONS` | Upper bound on parallel inner batches for this query, not a guaranteed writer count |
| `OF 500 ROWS` | Batch size in incoming outer rows, not necessarily relationship count; native scheduling may start partially filled batches |
| `DISJOINT BY (...)` | Declare keys for resources that must not overlap across simultaneously executing batches |
| `ON ERROR RETRY FOR 10 SECONDS` | Bounded transient-error recovery, not a transaction timeout or lock-wait setting |
| `THEN FAIL` | Fail the outer query if retries are exhausted; prior commits remain durable |

A maximum of roughly 8,000 outer rows can be in 16 fully populated running batches at once. That is not a heap estimate or an exact lock count. Additional queued batches and outer-query state can also consume memory.

### 5.2 Selecting DISJOINT BY expressions correctly

Treat these expressions as a conservative description of incompatible write resources, not merely a convenient partitioning key. Explicit expressions are the entire declared set: they do not get supplemented by automatic inference. They must be available in the outer scope [5].

| Workload | Candidate declaration | Reason / caveat |
|---|---|---|
| Same-label source and target; both may conflict | `(row.sourceId, row.targetId)` | Use one canonical identity namespace across both roles; Neo4j documents this form for account-to-account transfers |
| Distinct endpoint populations with overlapping raw IDs | `(row.sourceKey, row.targetKey)` | Construct typed canonical IDs such as `Account:42` and `Security:42` upstream; do not prefix by source/target role when the same physical node can appear in both |
| Both endpoints plus independently contended business identity | `(row.sourceKey, row.targetKey, row.relationshipKey)` | Include additional known conflict resources, using a distinct namespace for relationship identity |
| Relationship property-only updates | `(row.relationshipKey)` | Candidate when the only relevant mutations are to identified existing relationships; consider other unique index keys and concurrent topology changes |
| Certified independent endpoint/relationship work | `NONE` | No scheduler protection; validate against real query and competing writers |
| Known dense shared target, append-only CREATE | `(row.sourceKey)` | Experimental relaxation only: omit target exclusivity only after proving workload eligibility and benchmarking residual contention |

Use canonical, non-null keys representing the same physical entity even if the input can refer to it through different identifiers. Normalize types and aliases upstream. Avoid a constant, label-only key, or broad type key that serializes unrelated work. Conversely, a composite edge key alone (e.g. `sourceId + targetId`) is too narrow when edges sharing a single endpoint conflict. Do not assume list-valued expressions are expanded into individual resource keys; use documented scalar expressions or external scheduling.

Test cross-role conflicts explicitly: A→B and C→A must not run together under the conservative same-population policy. Neo4j's documented account-to-account example uses both endpoint IDs [5]; verify the behavior of the installed release with a small instrumented fixture, including same-ID aliases, self-loops, duplicate relationship keys and mixed labels. Do not reorder the direction of the actual edge merely to canonicalize a scheduling key.

### 5.3 Explicit versus AUTO versus NONE

- `DISJOINT BY (expressions)`: preferred initial option when the write set is understood.
- `DISJOINT BY AUTO`: planner inference; indexed merge keys are necessary for the documented inference path. Inspect inferred expressions with `EXPLAIN`; absence of inferred keys means execution is unrestricted. Do not assume AUTO captures every conflicting resource.
- `DISJOINT BY NONE`: explicitly disables scheduling, useful as a controlled benchmark and for eligible dense-node CREATE lanes.

A database default can be configured using `dbms.cypher.transactions.default_subquery_batch_strategy` (`NONE`, `AUTO`, `DEFAULT`); explicit query-level selection overrides it [5, 6]. Prefer query-scoped experiments before changing the shared database default.

The clause coordinates batches within its own query execution. It does not establish exclusive application-level ownership across separate sessions, producers, or unrelated online mutations. Use normal database locking and retries, and coordinate ingestion lanes externally where necessary.

## 6. Practical tuning: rows, concurrency and conflict expressions

### 6.1 Establish a reproducible baseline

Use a representative snapshot and identical input records for every run. Preserve real degree distribution, hot-node write concentration, relationship types, create/update/delete mix and arrival bursts. Restore the same starting state for every run; replaying a previously inserted workload changes CREATE/MERGE semantics and density. Run with the same indexes, hardware, database settings, writer topology and comparable cache conditions. Include normal concurrent reads when measuring production suitability.

Capture committed unique relationship count and elapsed time, deadlocks, retries, failed rows, p95/p99 transaction latency, heap, garbage collection, page-cache behavior, disk/transaction-log latency, CPU, replication lag, and end-to-end ingestion backlog. Repeat promising runs at least three times and compare medians and variability.

### 6.2 Step 1 — optimize batch composition before increasing workers

Random mixing causes many batches to touch the same hotspots. Grouping edges by a highly contended endpoint reduces the number of separate batches that reference multiple hot nodes.

For a predominantly many-to-one topology, try sorting by target key and then source key. For a predominantly one-to-many topology, reverse the primary sort. If both endpoint populations overlap, sorting one side is only a heuristic; both ends remain relevant. Use explicit partitioning if sorting does not deliver sufficient independence.

For bounded parameter chunks, an explicit order can be applied before the subquery:

```cypher
CYPHER 25
UNWIND $rows AS row
WITH row ORDER BY row.targetId, row.sourceId, row.relationshipId
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  MERGE (a)-[r:CONNECTED_TO {id: row.relationshipId}]->(b)
  SET r.value = row.value
} IN 8 CONCURRENT TRANSACTIONS OF 250 ROWS
  DISJOINT BY (row.sourceId, row.targetId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
```

For large files, pre-sort or partition upstream instead of introducing a large in-database sort. Ordering the input influences batch formation, not concurrent commit order. Compare native scheduling with and without sorted input; the runtime can form partial batches. A long consecutive stream containing only one hotspot can also starve independent work; interleave *groups* for independent resources, not individual random edges.

**Quantitative intuition:** Assume a hot node appears in 1% of independently shuffled rows. For a fixed batch of B rows, the chance that the batch touches that node is `1 - (1 - 0.01)^B`.

| Batch size B | Chance batch contains the hot node |
|---:|---:|
| 50 | 39.5% |
| 100 | 63.4% |
| 250 | 91.9% |
| 500 | 99.3% |
| 1,000 | 99.996% |

At 500 rows, nearly every randomly formed batch would contend for the same exclusive key, even though only 1% of rows touch that key. For 16 such batches, the expected number touching it is approximately 15.9. With grouped input, that same hot-key population can be concentrated in far fewer batches. This model is illustrative: real arrivals are correlated and native batch formation is not necessarily fixed or random.

### 6.3 Step 2 — sweep transaction size

Hold concurrency at 4 or 8 and hold key policy and row ordering constant. Start with these proposed candidates:

| Rows per transaction | What to learn |
|---:|---|
| 50, 100 | Hotspot-heavy baseline; smaller lock footprints, more commits |
| 250, 500 | Likely useful middle range to explore |
| 1,000, 2,000 | Whether commit amortization outweighs larger conflict sets |
| 5,000 | Optional for grouped, low-contention or bulk loads; measure memory and tail latency carefully |

These are experiment values, not universal Neo4j recommendations. The default row count is 1,000 if omitted [5, 7]. Reduce B if lock waits, deadlocks, transaction memory or rollback cost rise. Increase B if transactions are short, lock waits negligible, and commit/driver overhead dominates. Stop before violating latency or memory budgets.

Measure distinct exclusive keys per batch, maximum and percentile batch footprints, rows per completed batch, actual bytes and operations per row, and number of batches each hotspot appears in. A batch of 500 edges touching one hot target and 500 unique sources can have much less conflict than 500 edges touching 50 hot targets.

Do not enlarge every transaction to fit the largest supernode. Isolate outliers into bounded chunks and a dedicated lane. A 100,000-edge transaction could introduce long lock lifetimes and high rollback cost. Also bound the outer parameter chunk size independently of the inner batch size.

### 6.4 Step 3 — sweep concurrency

For the two or three best batch sizes, test 1 (serial baseline), 2, 4, 8, 16, 32, and optionally 64 concurrent transactions if hardware and operational headroom permit. Keep the number of outer queries fixed initially. For the truly serial baseline use `IN TRANSACTIONS`, removing `DISJOINT BY`.

A useful approximation when the system is not saturated is:

```
committed throughput ≈ average running batches × average committed edges per batch
                       / average batch service time
```

Include retry overhead and aborted attempts when measuring actual wall-clock throughput. The configured writer count cannot substitute for observed concurrency. Increase workers only while committed throughput improves enough to justify resource and latency costs. Select the smallest concurrency near the throughput plateau (e.g., within 5% of the best eligible run; proposed engineering rule).

If four independent application sessions each run `IN 16 CONCURRENT TRANSACTIONS`, as many as 64 inner transactions may be attempted, subject to database limits. Coordinate a global concurrency budget rather than tuning each session in isolation. Neo4j's writer/leader, storage and replication capacity may constrain total throughput.

### 6.5 Step 4 — compare scheduling policies

For each promising `(concurrency, rows)` pair, test the following against the same fixture:

| Test | Row order | Scheduling |
|---|---|---|
| A | Existing | Existing production approach |
| B | Existing | Explicit both-endpoint keys |
| C | Grouped | Explicit both-endpoint keys |
| D | Grouped | AUTO, after confirming inferred keys |
| E | Grouped/partitioned | NONE, only on controlled test or independently coordinated work |
| F | Degree-aware lanes | Conservative keys for sparse/MERGE; reduced keys for qualified dense CREATE |

Do not remove a necessary conflict key merely because the profiler shows it is expensive. Verify the changed write semantics, constraint interactions and external concurrency first.

### 6.6 Step 5 — use concurrency PROFILE to decide the next adjustment

From Neo4j 2026.10, the `TransactionForeach` / `TransactionApply` plan exposes concurrency statistics [5]. For example, use `CYPHER 25 PROFILE` before the `UNWIND` of a test write query. `EXPLAIN` only plans; `PROFILE` executes and commits. Collect timing separately without profiling overhead for final throughput comparisons.

Relevant plan argument: `concurrent-transactions`. Read `concurrencyLimit`, `avgConcurrency`, `peakConcurrency`, `avgQueuedBatches`, `avgStartGapNanos`, `batchesQueued`, `innerTransactionsStarted`, `innerTransactionsCommitted`, and `retries`.

| Symptom | Likely bottleneck | Next action |
|---|---|---|
| Low running concurrency; many queued batches; low lock waits | Declared resource overlap or slow result consumer | Inspect footprint; group rows, isolate hot keys, reduce batch size, verify consumer throughput |
| Low running concurrency; almost no queued batches | Input supply/outer-query bottleneck | Improve parsing, indexed lookup, chunk supply or upstream preparation |
| Running concurrency near limit; queue remains; CPU/storage headroom | Too few workers | Increase concurrency one step and remeasure |
| Running concurrency near limit; throughput plateaus; CPU or I/O saturated | Server capacity | Stop increasing writers; reduce load or address resource bottleneck |
| High deadlocks/retries despite declared keys | Missing conflict resources, other queries, legacy storage, index locks | Examine exception lock types, query plan, cross-role identity and all producers |
| High lock waits; few deadlocks | Contention without cycles | Reduce overlap or transaction duration; inspect hot-node path |
| High memory/GC; long p99 | Large write sets or too many batches | Reduce rows and/or concurrency |
| Many undersized batches | Scheduler or grouping fragmentation | Improve grouping; inspect actual rows per commit; adjust size and keys |

Use this feedback loop instead of setting 16 and 500 permanently. On earlier versions, instrument driver transactions and sample active locks/waits, then derive actual throughput from committed counts.

### 6.7 Retry, checkpoint and correctness rules

Keep bounded retries for residual transient errors. Ten seconds is an illustrative recovery budget; choose it from end-to-end latency and failure policy. Increasing the retry budget does not eliminate contention. `THEN FAIL` is the default fallback; explicitly using it makes intent clear. Do not mistake a failed outer statement for atomic rollback of all inner batches.

If intentionally continuing after failed batches, use `THEN CONTINUE REPORT STATUS AS status`, return a stable input ID and status, persist failures, and replay them. This requires an idempotent reconciliation process. Check missing endpoint matches independently, since a transaction can commit without applying the expected edge.

Do not rely on concurrent commit order for events affecting the same identity. Use sequence/version checks or coordinated per-key order, and acknowledge/checkpoint input only after durable results are established. Handle unknown commit outcomes on network failures. Never advance a Kafka/CDC checkpoint past unresolved work without a durable gap-tracking mechanism.

## 7. Hot-node-specific ingestion lanes

Start with one conservative lane. Add a specialized lane only when measurements justify it:

| Operation class | Proposed policy |
|---|---|
| Sparse/unknown endpoints, true MERGE | Exclusive endpoint scheduling |
| New edge, known dense target, independent sparse sources | Bound shared target concurrency; exclusive sources |
| New edge, both endpoints dense | Experiment with bounded shared permits at both endpoints |
| Existing relationship property update | Relationship identity scheduling, coordinate with delete/create and constraints |
| Node properties, labels, deletion | Coordinate exclusive node access with all relevant relationship lanes |

Density is a hint, not a correctness guarantee. Do not automatically increase permits solely because degree is high. Use observed behavior by relationship type and storage format. No node property/label updates, topology deletions or competing incompatible writers should bypass the admission policy.

Example for a controlled append-only dense-target workload:

```cypher
CYPHER 25
UNWIND $rows AS row
CALL (row) {
  MATCH (a:Entity {id: row.sourceId})
  MATCH (b:Entity {id: row.targetId})
  CREATE (a)-[:CONNECTED_TO {id: row.relationshipId}]->(b)
} IN 4 CONCURRENT TRANSACTIONS OF 100 ROWS
  DISJOINT BY (row.sourceId)
  ON ERROR RETRY FOR 10 SECONDS THEN FAIL;
```

**Eligibility:** The omitted target resource must be a verified dense attachment point for the relevant type; the operation is CREATE-only; the source identities and their other mutations are controlled; no overlapping relationship identities or other conflicting index keys; no incompatible node mutations. Do not use this blindly for account-to-account graphs where the same physical node may also appear in an exclusive source role. Maintain global coordination between lanes. Neo4j still determines actual locking, and residual deadlocks remain possible.

Benchmark target writer budgets 1, 2, 4, 8, and possibly 16. For a single extremely hot target, a separate query with a fixed budget is a straightforward first experiment. If its performance improves, extend to multiple targets using a central admission controller. Do not launch one unrestricted concurrent query per hot node.

## 8. External scheduling and weighted partitioning

Native scheduling is attractive for one coordinated ingestion query, but multiple producers may require cross-query control. Neo4j's published Mix and Batch and subsequent generalization provide starting algorithms [8, 10]. The Parallel Spark Loader balances groups by relationship row counts rather than node counts alone [11].

### Bipartite graph

When source and target physical node sets are genuinely disjoint, use P source partitions and P target partitions. Bucket rows by `(hash(source) mod P, hash(target) mod P)`. In phase k, worker i owns bucket `(i, (i+k) mod P)`. P phases cover P² combinations with up to P simultaneous workers. Each phase reserves disjoint endpoint partitions; workers must finish before the next phase changes ownership.

### Same-population graph

For account-to-account or person-to-person graphs, use a common partition function on both endpoints. Bucket cross-partition relationships by unordered partition pair, preserving actual edge direction in the payload. With an even P, a round-robin matching schedule covers cross-partition pairs in P-1 phases with P/2 workers. A separate phase handles within-partition pairs with up to P workers. Odd P can use a dummy partition. This avoids role-based overlap. On legacy record storage, indirect chain locking may still cause conflicts.

### Weighting for skew

Use recent endpoint write counts, operation cost and contention observations to assign nodes/partitions to workers. Grouping must preserve conflict ownership. Avoid splitting an exclusive resource across multiple workers simply to balance the row count. No exclusive partitioning algorithm can distribute a single unsplittable hot node's work across simultaneous transactions. Shared dense-node concurrency or physical sharding is necessary to go beyond that limit.

### Dynamic admission control for continuous ingestion (proposed architecture)

Replace global phase barriers with a dispatcher that admits any queued batch whose complete resource set is compatible with active work.

```
Durable input (Kafka / CDC / batch files)
    -> canonicalize identities and deduplicate/reconcile
    -> classify operations and build bounded microbatches
    -> shared/exclusive resource admission + weighted fair queues
    -> bounded worker pool
    -> Neo4j commit/rollback acknowledgement
    -> checkpoint and release reservations
```

Reserve all relevant resources atomically, or reserve none; never hold one resource while waiting indefinitely for another. Release reservations only when the database transaction outcome is known or the old transaction has been safely stopped. Provide backpressure, age-based fairness, crash recovery, and fencing/ownership controls across dispatcher failover. A lease expiry alone is insufficient to fence an already running database transaction.

Adaptive permits can start at one and increase slowly for qualified dense resources as long as committed throughput improves, backlog exists, and lock waits remain within budget. On elevated deadlock/retry rates or tail latency, reduce permits (e.g. halve) and allow a cooldown. Bound the aggregate worker pool. Use independent observations and hysteresis to avoid oscillation. This shared/exclusive adaptive scheduling scheme is a proposed design, not a Neo4j built-in feature or a benchmarked implementation. General transaction scheduling research such as Strife provides conceptual precedent [13].

## 9. If native dense-node concurrency is insufficient

Consider physical attachment-node sharding only after optimizing storage, query semantics and scheduling. For example:

```
(:Account)-[:CONNECTED_TO]->(:SecurityBucket)-[:BUCKET_OF]->(:Security)
```

Pre-create a fixed number of buckets for each hot logical security. Assign edges by a stable hash of the other endpoint or edge ID. This spreads physical attachment work while retaining logical identity. Changing bucket counts requires a versioned mapping and migration strategy. If a single other endpoint is also hot, sharding one side alone will not resolve that conflict.

Trade-offs: additional nodes and traversal hops, query rewrites, potential changes to graph algorithm results, identity/constraint design, and migration complexity. Use a logical projection for analytics requiring the original topology. Do not make this change solely to eliminate a small retry rate.

For offline initial population rather than continuous transactional ingestion, evaluate `neo4j-admin database import full`. Incremental import has operational prerequisites and maintenance stages; assess these against availability requirements [14].

## 10. Diagnostics and benchmark acceptance

### Observe degree and write skew

```cypher
MATCH (n:Entity)
WITH n, COUNT { (n)-[:CONNECTED_TO]-() } AS degree
RETURN n.id AS nodeId, degree
ORDER BY degree DESC LIMIT 100;
```

```cypher
MATCH (n:Entity)
WITH COUNT { (n)--() } AS degree
RETURN count(*) AS nodes, avg(degree) AS mean,
       percentileDisc(degree, 0.5) AS p50,
       percentileDisc(degree, 0.95) AS p95,
       percentileDisc(degree, 0.99) AS p99,
       percentileDisc(degree, 0.999) AS p999,
       max(degree) AS maxDegree;
```

Run expensive full-graph diagnostics off the critical write path. Measure per-type endpoint counts in incoming data separately; the graph's existing degree distribution is not a measure of incoming write frequency.

### Inspect locks and transaction state

```cypher
SHOW TRANSACTIONS
YIELD transactionId, currentQueryId, currentQuery, status,
      elapsedTime, waitTime, activeLockCount, estimatedUsedHeapMemory
RETURN * ORDER BY waitTime DESC;
```

```cypher
CALL dbms.listActiveLocks($queryId);
```

Check fields and procedure privileges on the deployed version. Capture full deadlock messages with query/template identity, batch ID, operation type, endpoint keys and timestamps (redact sensitive data). `NODE` suggests endpoint/node conflicts; `RELATIONSHIP` can indicate existing edges or chain maintenance; `INDEX_ENTRY` can indicate uniqueness/key contention; group and degree resources point to structural synchronization. Internal lock names and semantics are version dependent [1]. Lock-wait timeouts are distinct from retry duration and do not cure deadlocks.

### Proposed benchmark grid

| Variable | Candidate values |
|---|---|
| Existing degree of hot nodes | 10, 50, 1,000, 100,000, 1,000,000 |
| Incoming rows touching top node | 1%, 10%, 25%, 50%, 90% |
| Endpoint topology | Sparse-sparse; sparse-dense; dense-dense; same-population; bipartite |
| Write mix | CREATE-only; MERGE-only; property update; realistic mixed deletes/updates |
| Rows per batch | 50, 100, 250, 500, 1,000, 2,000; optional 5,000 |
| Concurrency | 1, 2, 4, 8, 16, 32; optional 64 |
| Input composition | Shuffled; sorted/grouped; weighted partitions |
| Store format | Current production format; block if supported |
| Scheduler | Existing; explicit; AUTO; NONE; external/adaptive |

Use staged experiments rather than a full Cartesian product. First isolate single-variable causes, then retest combinations of the strongest settings on representative mixed traffic.

Example results sheet columns:

```
run_id,neo4j_version,store,operation,skew,row_order,keys,workers,rows,
committed_unique_edges,elapsed_seconds,edges_per_second,deadlocks,retries,
failed_rows,avg_concurrency,avg_queue,p99_tx_ms,p99_read_ms,peak_heap,
log_write_latency,replication_lag,backlog,notes
```

Acceptance criteria should be defined with production owners: required sustained and burst rates, no missing/duplicate business identities, correct per-key update order, bounded backlog, acceptable read/write tail latency, resource headroom, acceptable retry/failure rates, and recovery from worker crash or unknown commit. Test deliberate retry/replay and missing endpoint scenarios before rollout.

## 11. Published evidence and its limitations

- **Neo4j 4.3 relationship-chain locks (2021):** vendor engineering work specifically targeting concurrent relationship changes around celebrity-style supernodes [12]. Historical evidence that dense-node concurrency is a real engine capability, not proof of scalability on the current deployment.
- **October 2026 engineering benchmark [9]:** six CPUs, 8 GB container memory, 3.2 million input rows, 5,000-row batches. Results are reproduced below as reported, not independently replicated.

| Workload | Serial | Native DISJOINT BY | External partitioning |
|---|---:|---:|---:|
| HAS_OPERATION relationships | 91.5 s | 60.0 s | 14.5 s |
| IS_LINKED_TO relationships | 53.9 s | 30.9 s | 31.5 s |
| Complete pipeline | 250.6 s | 207.8 s | 186.5 s |

The external grouping approach delivered approximately 69,000 HAS_OPERATION relationships/sec compared with 10,900/sec serial. The author suggests repeated contract IDs across native batches as a possible explanation for the difference. This motivates testing batch composition before increasing concurrency; it does not establish a universal advantage for an external scheduler or an optimal batch size. The full pipeline also included node loading and differed in staging/transport paths.

- **Mammoths Are Slow (VLDB 2024) [15]:** graph transaction experiments including skewed social-network degrees and interference between large and smaller concurrent transactions. Supports testing transaction footprints and mixed workloads, but is not a direct benchmark of the proposed dense-node CREATE lane.
- **Strife (SIGMOD 2020) [13]:** independent transaction scheduling research using dynamic grouping for high-contention transactional workloads. Conceptual support for adaptive scheduling, not a Neo4j implementation.

## 12. Recommended execution plan

| Stage | Deliverable |
|---|---|
| 1. Diagnose | Version/format inventory, query plans, deadlock examples, endpoint degree/write heat distribution |
| 2. Low-risk changes | Indexed endpoints, separate node and relationship mutations, deduplication and replay design |
| 3. Native scheduling | Compare explicit keys, AUTO, grouped input and batch/concurrency sweeps |
| 4. Dense-node optimization | Bounded CREATE lane; verify shared endpoint concurrency and correctness under load |
| 5. Distributed coordination | Weighted partitioning or adaptive scheduler if native per-query coordination is insufficient |
| 6. Model changes | Evaluate sharding only if measured throughput still cannot meet requirements |

**Open inputs:** deployed Neo4j version and edition, store format, real ingestion query, producer count, hardware and cluster topology, representative lock exceptions, degree and write-rate percentiles, target throughput, and correctness/latency requirements. None were supplied for this report. The tuning ranges and proposed scheduling design are hypotheses to validate, not production-ready settings or throughput guarantees. Code examples were checked against documented syntax but not executed on a live Neo4j instance.

## References

Official documentation links were checked for this report on November 26, 2026. Version-pinned documentation should be used when implementing against an older release.

1. Neo4j Operations Manual, [Concurrent data access](https://neo4j.com/docs/operations-manual/current/database-internals/concurrent-data-access/).
2. Neo4j Operations Manual, [Store formats](https://neo4j.com/docs/operations-manual/current/database-internals/store-formats/).
3. Neo4j Cypher Manual, [MERGE](https://neo4j.com/docs/cypher-manual/current/clauses/merge/).
4. Neo4j Cypher Manual, [Query plan operators](https://neo4j.com/docs/cypher-manual/current/planning-and-tuning/operators/).
5. Neo4j Cypher Manual, [CALL subqueries in transactions — batching, DISJOINT BY, retries, concurrency profiling](https://neo4j.com/docs/cypher-manual/current/subqueries/subqueries-in-transactions/).
6. Neo4j Operations Manual, [Configuration settings](https://neo4j.com/docs/operations-manual/current/configuration/configuration-settings/).
7. Neo4j Data Ingestion Guide, [Transactional and concurrent Cypher ingestion](https://neo4j.com/docs/data-ingestion-guide/best-practices/transactional-and-concurrent-cypher-ingestion/).
8. Maxime Guery, [Massive Parallel Imports in Neo4j Without Deadlock and Lock Contention](https://neo4j.com/blog/graph-data-science/massive-parallel-imports-in-neo4j-without-deadlock-and-lock-contention/), September 2026.
9. Maxime Guery, [Implementation of the Neo4j Import Without Deadlock and Lock Contention](https://medium.com/neo4j/implementation-of-the-neo4j-import-without-deadlock-and-lock-contention-1755862e6243), October 2026.
10. Neo4j Developer Blog, [Mix and batch: a technique for fast, parallel relationship loading](https://neo4j.com/blog/developer/mix-and-batch-relationship-load/), 2024.
11. Neo4j Developer Blog, [Use Neo4j Parallel Spark Loader to improve large-scale ingestion jobs](https://neo4j.com/blog/developer/parallel-spark-loader-ingestion/), 2025; [implementation repository](https://github.com/neo4j-field/neo4j-parallel-spark-loader).
12. Stu Moore, [Relationship chain locks and graph locks: Don't block the rock!](https://neo4j.com/blog/developer/relationship-chain-locks-dont-block-the-rock/), 2021.
13. Guna Prasaad, Alvin Cheung, Dan Suciu, [Handling Highly Contended OLTP Workloads Using Fast Dynamic Partitioning](https://homes.cs.washington.edu/~suciu/guna-sigmod-2020-pdfa.pdf), ACM SIGMOD 2020.
14. Neo4j Operations Manual, [Database import](https://neo4j.com/docs/operations-manual/current/import/).
15. Audrey Cheng et al., [Mammoths Are Slow: The Overlooked Transactions of Graph Data](https://www.vldb.org/pvldb/vol17/p904-cheng.pdf), PVLDB 17, 2024.
