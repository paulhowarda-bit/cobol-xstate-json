# Direct WebFetch research catalog

Research snapshot: November 26, 2026. URLs below are intentionally plain, stable links so a Claude Code agent with WebFetch but no WebSearch can retrieve them. Official docs override historical blog advice for the deployed release. The bundled report supplies offline findings; this catalog does not redistribute entire third-party articles. Access may depend on corporate network restrictions; use alternate publisher links where listed. Do not send any internal data to these URLs.

## Tier 1 — authoritative, fetch first

| ID | Direct URL | What to extract |
|---|---|---|
| N01 | https://neo4j.com/docs/cypher-manual/current/subqueries/subqueries-in-transactions/ | Syntax, defaults, concurrency semantics, DISJOINT BY explicit/AUTO/NONE, retry behavior, 2026.10 profiling metrics |
| N02 | https://neo4j.com/docs/cypher-manual/25/subqueries/subqueries-in-transactions/ | Cypher 25-specific documentation, batch scheduling section |
| N03 | https://neo4j.com/docs/cypher-manual/5/subqueries/subqueries-in-transactions/ | Older 5.x support; 5.21 concurrent form |
| N04 | https://neo4j.com/docs/cypher-manual/5/subqueries/call-subquery/ | 5.23 variable scope clause, importing variables |
| N05 | https://neo4j.com/docs/cypher-manual/current/queries/select-version/ | Cypher 25 introduced 2025.06, installed dialect selection |
| N06 | https://neo4j.com/docs/operations-manual/current/database-internals/concurrent-data-access/ | Exact dense/sparse lock behavior, deadlock detection, lock inspection |
| N07 | https://neo4j.com/docs/operations-manual/current/database-internals/store-formats/ | Block storage, legacy chains, density by type, migration considerations |
| N08 | https://neo4j.com/docs/cypher-manual/current/clauses/merge/ | Endpoint locking on missing relationship, uniqueness constraints |
| N09 | https://neo4j.com/docs/cypher-manual/current/planning-and-tuning/operators/ | LockingMerge, MergeInto, indexed relationship operators |
| N10 | https://neo4j.com/docs/cypher-manual/current/planning-and-tuning/execution-plans/ | EXPLAIN vs PROFILE, concurrency column and plan interpretation |
| N11 | https://neo4j.com/docs/operations-manual/current/configuration/configuration-settings/ | default_subquery_batch_strategy, default_subquery_retry_timeout, transaction/lock/memory limits |
| N12 | https://neo4j.com/docs/operations-manual/current/database-internals/transaction-management/ | Transaction limits and lifecycle |
| N13 | https://neo4j.com/docs/cypher-manual/5/constraints/syntax/ | Relationship uniqueness introduced 5.7, constraint syntax |
| N14 | https://github.com/neo4j/neo4j/wiki/Neo4j-2026-changelog | 2026.06 feature introduction, per-outer-query limitation, newer fixes |
| N15 | https://neo4j.com/docs/cypher-manual/current/deprecations-additions-removals-compatibility/ | Version gates and changes |
| N16 | https://neo4j.com/docs/cypher-manual/5/deprecations-additions-removals-compatibility/ | 5.x version gates |
| N17 | https://neo4j.com/docs/data-ingestion-guide/ | Ingestion methods and official best practices |
| N18 | https://neo4j.com/docs/data-ingestion-guide/best-practices/transactional-and-concurrent-cypher-ingestion/ | Batch sizes, split dependent phases, retries, DISJOINT BY |
| N19 | https://neo4j.com/docs/data-ingestion-guide/best-practices/optimized-cypher/ | Indexed patterns, node/relationship staging and preprocessing |
| N20 | https://neo4j.com/docs/data-ingestion-guide/best-practices/schema-and-indexes/ | Schema and query plan checks |
| N21 | https://neo4j.com/docs/java-manual/current/query-advanced/ | Implicit session.run, consuming results, driver behavior |
| N22 | https://neo4j.com/docs/operations-manual/current/monitoring/metrics/reference/ | Exact metrics names available for deployment |
| N23 | https://neo4j.com/docs/operations-manual/current/monitoring/logging/ | Query and transaction logs |
| N24 | https://neo4j.com/docs/operations-manual/current/import/full-import/ | Administrative bulk loading and limitations |
| N25 | https://neo4j.com/docs/operations-manual/current/import/incremental-import/ | Incremental staged import and constraints/downtime |
| N26 | https://neo4j.com/docs/operations-manual/current/import/create-drop-indexes/ | Schema operations during administrative import |
| N27 | https://neo4j.com/docs/operations-manual/current/import/header-format/ | Bulk file schema and ID spaces |
| N28 | https://neo4j.com/docs/apoc/current/overview/apoc.periodic/apoc.periodic.iterate/ | Legacy iterate semantics and deprecation in 2026.04 Cypher 25 |
| N29 | https://neo4j.com/docs/apoc/current/apoc-and-cypher/cypher-migration/ | Native Cypher replacements for APOC |
| N30 | https://neo4j.com/docs/kafka/current/sink/configuration/ | Connector batch and task controls |
| N31 | https://neo4j.com/docs/kafka/current/sink/cypher/ | Connector custom Cypher binding/semantics |
| N32 | https://neo4j.com/docs/kafka/current/sink/best-practices/ | Strategy choice, delivery guarantees and tuning |
| N33 | https://neo4j.com/docs/kafka/current/sink/pattern/ | Version-specific exactly-once pattern sink options |
| N34 | https://neo4j.com/docs/kafka/current/sink/cdc/ | CDC batching and offsets |
| N35 | https://neo4j.com/docs/spark/current/performance/tuning/ | Spark connector sizing and write partitioning |
| N36 | https://neo4j.com/docs/data-ingestion-guide/ingestion-methods/spark-connector/ | Spark ETL and relationship ingestion |
| N37 | https://neo4j.com/docs/cypher-manual/current/appendix/grammar/ | Exact grammar for uncertain syntax |

## Tier 2 — engineering articles and implementations

| ID | Direct URL | Key relevance / caveat |
|---|---|---|
| B01 | https://neo4j.com/blog/developer/relationship-chain-locks-dont-block-the-rock/ | 2021 dense-node locking change, celebrity/follower benchmark; historical engine version |
| B02 | https://neo4j.com/blog/developer/mix-and-batch-relationship-load/ | 2024 bipartite partition scheduling; not safe unchanged for same-population graphs |
| B03 | https://neo4j.com/blog/developer/parallel-spark-loader-ingestion/ | 2025 weighted grouping and large ETL workloads; preprocessing costs matter |
| B04 | https://github.com/neo4j-field/neo4j-parallel-spark-loader | Implementation, inspect actual version and algorithms before adopting |
| B05 | https://pypi.org/project/neo4j-parallel-spark-loader/ | Package versions and requirements, do not install without approval |
| B06 | https://neo4j.com/blog/graph-data-science/massive-parallel-imports-in-neo4j-without-deadlock-and-lock-contention/ | September 2026 generalized graph-coloring / matching for shared endpoint populations |
| B07 | https://medium.com/neo4j/massive-parallel-imports-in-neo4j-without-deadlock-and-lock-contention-2c003a48d49a | Alternate publisher link for B06 |
| B08 | https://medium.com/neo4j/implementation-of-the-neo4j-import-without-deadlock-and-lock-contention-1755862e6243 | October 2026 benchmark comparing serial, native DISJOINT BY and external grouping; block vs record chain caveat; do not generalize one dataset |
| B09 | https://graphacademy.neo4j.com/blog/replace-apoc-periodic-iterate-with-call-in-transactions | Native transactional batching migration from APOC |

## Tier 3 — independent academic context

| ID | Direct URL | Key relevance |
|---|---|---|
| P01 | https://www.vldb.org/pvldb/vol17/p904-cheng.pdf | Mammoths Are Slow, VLDB 2024; graph transaction interference and skewed graph benchmark |
| P02 | https://homes.cs.washington.edu/~suciu/guna-sigmod-2020-pdfa.pdf | Strife, SIGMOD 2020; dynamic conflict grouping for OLTP, conceptual not Neo4j implementation |

If PDF WebFetch cannot parse the paper, use the local report's summary and say full paper was not fetched. Do not claim exact results from an unread paper. These links are research sources, not approved corporate dependencies.

## Claude Code installation docs

https://code.claude.com/docs/en/skills — official skill discovery and folder layout.

## Example WebFetch task prompts

For N01: "Find the exact version requirements and syntax for CALL IN CONCURRENT TRANSACTIONS, DISJOINT BY explicit/AUTO/NONE, whether keys are evaluated outside the subquery, local scope of scheduling, retry fallback and 2026.10 concurrency statistics. Return a concise technical summary and cite the section headings."

For N06/N07: "Distinguish sparse vs dense relationship locks, format-specific density and commit locking. Identify why CREATE and MERGE may differ; do not infer guarantees beyond the documented behavior."

For B08: "Extract hardware, dataset, rows/transaction, writer count, per-relationship and overall timing, limitations of record formats and whether preprocessing/transport paths differ. Separate measured results from author's hypotheses."

For N14: "Check feature introduction and subsequent fixes for transaction scheduling and concurrent ingestion. Compare to the installed version, not just latest."

Refresh only the required sources for the task, store local summaries with retrieval date if allowed, and cite direct URLs in deliverables. If sources disagree, prioritize version-matched official docs and test the installed system. The prior report is a research synthesis; no live database was benchmarked here.
