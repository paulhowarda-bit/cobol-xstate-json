#!/usr/bin/env python3
"""Local, bounded CSV prefix analysis. No database/network calls. Python 3 stdlib."""
import argparse
import csv
import json
import math
from collections import Counter
from itertools import islice


def percentile(values, q):
    s = sorted(values)
    return s[max(0, math.ceil(q * len(s)) - 1)] if s else 0


def batches(rows, size, hot_keys):
    footprints, hot_counts = [], Counter()
    adjacent_conflicts, previous = 0, set()
    for i in range(0, len(rows), size):
        keys = {x for row in rows[i:i + size] for x in row}
        footprints.append(len(keys))
        hot_counts.update(keys & hot_keys)
        if i and keys & previous:
            adjacent_conflicts += 1
        previous = keys
    n = len(footprints)
    return dict(batches=n, mean_distinct_keys=round(sum(footprints)/n, 2) if n else 0,
                p95_distinct_keys=percentile(footprints, .95),
                max_distinct_keys=max(footprints, default=0),
                hottest_key_batch_fraction=round(max(hot_counts.values(), default=0)/n, 4) if n else 0,
                adjacent_batch_overlap_fraction=round(adjacent_conflicts/(n-1), 4) if n > 1 else 0)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv_file')
    p.add_argument('--source', default='sourceId')
    p.add_argument('--target', default='targetId')
    p.add_argument('--source-namespace', default='node:')
    p.add_argument('--target-namespace', default='node:')
    p.add_argument('--limit', type=int, default=100000, help='Maximum prefix rows to read; not a random sample')
    p.add_argument('--sizes', default='50,100,250,500,1000,2000')
    args = p.parse_args()
    sizes = [int(x) for x in args.sizes.split(',')]
    if args.limit <= 0 or any(x <= 0 for x in sizes):
        p.error('limit and batch sizes must be positive')
    rows, invalid, frequency = [], 0, Counter()
    with open(args.csv_file, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or not {args.source, args.target} <= set(reader.fieldnames):
            p.error('required source and target columns are missing')
        for r in islice(reader, args.limit):
            a, b = r.get(args.source), r.get(args.target)
            if a is None or b is None or not a.strip() or not b.strip():
                invalid += 1
                continue
            # Input should already be canonical; do not silently normalize identifiers.
            pair = (args.source_namespace + a, args.target_namespace + b)
            rows.append(pair)
            frequency.update(set(pair))  # rows touching a key, not endpoint-reference count
    hot = frequency.most_common(10)
    keys = {k for k, v in hot}
    # No raw IDs in output. Use privacy-preserving aggregate metrics only.
    result = {'valid_rows': len(rows), 'invalid_rows': invalid, 'distinct_keys': len(frequency),
              'top_key_row_fractions': [round(v/len(rows), 6) for _, v in hot] if rows else [],
              'note': 'Bounded prefix, fixed batches, exclusive endpoint-key model. Not actual native scheduler or degree; no raw IDs.',
              'comparisons': {}}
    by_target = sorted(rows, key=lambda r: (r[1], r[0]))
    by_source = sorted(rows)
    for size in sizes:
        result['comparisons'][size] = {label: batches(data, size, keys) for label, data in
                                      [('original', rows), ('group_by_target', by_target), ('group_by_source', by_source)]}
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
